/* End-to-end test against local mock upstreams (no internet, no API keys needed). */
import http from 'node:http';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';

let sbCalls = 0, sbLog = [], serpCalls = 0;
const ld = JSON.stringify({ '@type': 'ItemList', itemListElement: [
  { '@type': 'ListItem', item: { '@type': 'Product', name: 'Philips Air Fryer HD9200 4.1L', image: '//img.snap.test/a.jpg', url: '/product/air-fryer-1', offers: { '@type': 'Offer', price: '5,499', highPrice: 7995, availability: 'https://schema.org/InStock' }, aggregateRating: { ratingValue: 4.3, reviewCount: 1200 } } },
  { '@type': 'ListItem', item: { '@type': 'Product', name: 'Generic Navigation Link', url: '/nav' } }] });
const next = JSON.stringify({ props: { items: [{ productName: 'Inalsa Air Fryer 4L Digital', sellingPrice: { value: 4299 }, mrp: 6999, imageUrl: 'https://img.snap.test/b.jpg', pdpUrl: '/p/inalsa' }] } });
const html = `<html><script type="application/ld+json">${ld}</script><script id="__NEXT_DATA__" type="application/json">${next}</script></html>`;

const mock = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'), j = (o, c = 200) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (u.pathname === '/token') return j({ access_token: 'tok', expires_in: 3600 });
  if (u.pathname === '/catalog/v1/searchItems') {
    let b = ''; req.on('data', d => b += d); return req.on('end', () => {
      assert.equal(req.headers.authorization, 'Bearer tok'); assert.equal(JSON.parse(b).partnerTag, 'testtag-21');
      j({ searchResult: { items: [{ asin: 'B1', detailPageURL: 'https://www.amazon.in/dp/B1?tag=testtag-21', itemInfo: { title: { displayValue: 'Amazon Basics Air Fryer 4L' }, byLineInfo: { brand: { displayValue: 'Amazon Basics' } }, features: { displayValues: ['Rapid air', '1500W'] } }, images: { primary: { medium: { url: 'https://m.media-amazon.com/x.jpg' } } }, offersV2: { listings: [{ isBuyBoxWinner: true, availability: { type: 'IN_STOCK' }, price: { money: { amount: 4999 }, savingBasis: { money: { amount: 6999 } }, savings: { percentage: 29 } } }] } }] } });
    });
  }
  if (u.pathname === '/affiliate/1.0/search.json') {
    assert.equal(req.headers['fk-affiliate-id'], 'fkid');
    return j({ products: [{ productBaseInfoV1: { title: 'Flipkart Air Fryer Pro', flipkartSellingPrice: { amount: 4599 }, flipkartSpecialPrice: { amount: 4399 }, maximumRetailPrice: { amount: 7999 }, productBrand: 'Pigeon', inStock: true, imageUrls: { '400x400': 'http://img.fk/x.jpeg' }, productUrl: 'http://dl.flipkart.com/dl/x?pid=1' }, categorySpecificInfoV1: { keySpecs: ['4 L', 'Digital'] }, productShippingInfoV1: { shippingCharges: { amount: 0 } } }] });
  }
  if (u.pathname === '/sb') {
    sbCalls++; sbLog.push(Object.fromEntries(u.searchParams));
    if (u.searchParams.get('url').includes('crm-fails')) { res.writeHead(500); return res.end('boom'); }
    if (u.searchParams.get('render_js') === 'false' && u.searchParams.get('url').includes('needsjs')) { res.writeHead(200); return res.end('<html>empty shell</html>'); }
    if (u.searchParams.get('extract_rules')) return j({ items: [{ title: 'Rule Based Air Fryer', price: '₹3,999', url: '/r/1', image: '/i.jpg' }] });
    res.writeHead(200); return res.end(html);
  }
  if (u.pathname === '/serp') { serpCalls++; return j({ shopping_results: [{ title: 'Croma Air Fryer 5L', source: 'Croma', extracted_price: 5999, thumbnail: 'https://t/x.jpg', product_link: 'https://google.test/p1' }, { title: 'Amazon dup', source: 'Amazon.in', extracted_price: 1, product_link: 'https://google.test/p2' }] }); }
  if (u.pathname === '/yt/search') return j({ items: [{ id: { videoId: 'abc123' }, snippet: { title: 'Air Fryer Review', channelTitle: 'Tech Guru', thumbnails: { high: { url: 'https://i.ytimg.com/vi/abc123/hq.jpg' } } } }] });
  if (u.pathname === '/yt/videos') return j({ items: [{ id: 'abc123', contentDetails: { duration: 'PT12M34S' } }] });
  j({ error: 'nope' }, 404);
});
await new Promise(r => mock.listen(0, r));
const M = 'http://127.0.0.1:' + mock.address().port, P = 3917;

const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT: P, ADMIN_KEY: 'adm', CORS_ORIGIN: '*',
  AMAZON_CLIENT_ID: 'id', AMAZON_CLIENT_SECRET: 'sec', AMAZON_PARTNER_TAG: 'testtag-21', AMAZON_TOKEN_URL: M + '/token', AMAZON_API_BASE: M,
  FLIPKART_AFFILIATE_ID: 'fkid', FLIPKART_AFFILIATE_TOKEN: 'fktok', FLIPKART_API_BASE: M + '/affiliate',
  SCRAPINGBEE_API_KEY: 'sb', SCRAPINGBEE_BASE: M + '/sb', SCRAPINGBEE_DAILY_CREDITS: '40', MAX_SCRAPE_STORES: '3',
  SERPAPI_API_KEY: 'sp', SERPAPI_BASE: M + '/serp', SERPAPI_DAILY_CALLS: '2', MIN_OFFERS: '12',
  YOUTUBE_API_KEY: 'yk', YOUTUBE_BASE: M + '/yt', STORE_RULES_JSON: JSON.stringify({ ike: { item: '.p', fields: { title: '.t', price: '.pr' } } }), CUELINKS_CID: '999' }, stdio: 'inherit' });
const B = 'http://127.0.0.1:' + P;
for (let i = 0; i < 50; i++) { try { await fetch(B + '/health'); break; } catch { await new Promise(r => setTimeout(r, 100)); } }

const get = async p => { const r = await fetch(B + p); return { r, j: await r.json() }; };
let pass = 0; const ok = (n, f) => { try { f(); pass++; console.log('  ✓', n); } catch (e) { console.log('  ✗', n, '\n   ', e.message); process.exitCode = 1; } };

try {
  console.log('search: electronics-style (home category = amz flk clq snp ike)');
  const { r, j } = await get('/api/search?q=air%20fryer&category=home');
  ok('200 + CORS header', () => { assert.equal(r.status, 200); assert.equal(r.headers.get('access-control-allow-origin'), '*'); });
  ok('offers array in the app\'s shape', () => { assert.ok(Array.isArray(j.offers) && j.offers.length >= 4); for (const o of j.offers) { assert.ok(o.title && o.price > 0 && o.store && 'url' in o && o.currency === 'INR'); } });
  ok('Amazon (Creators API) mapped incl. mrp/discount/stock/specs', () => { const o = j.offers.find(x => x.storeId === 'amz'); assert.equal(o.price, 4999); assert.equal(o.mrp, 6999); assert.equal(o.discountPercent, 29); assert.equal(o.inStock, true); assert.deepEqual(o.specs, ['Rapid air', '1500W']); assert.match(o.url, /tag=testtag-21/); });
  ok('Flipkart mapped (special price wins, https, affid kept, free delivery)', () => { const o = j.offers.find(x => x.storeId === 'flk'); assert.equal(o.price, 4399); assert.equal(o.mrp, 7999); assert.match(o.url, /^https:.*affid=fkid/); assert.equal(o.delivery, 'Free delivery'); assert.match(o.image, /^https:/); });
  ok('scraped store: ld+json + __NEXT_DATA__ harvested, noise row dropped', () => { const s = j.offers.filter(x => x.storeId === 'snp'); assert.equal(s.length, 2); assert.ok(s.find(x => x.price === 5499 && x.mrp === 7995 && x.rating === 4.3 && x.inStock === true)); assert.ok(s.find(x => x.title.includes('Inalsa') && x.price === 4299)); assert.ok(!j.offers.some(x => x.title.includes('Navigation'))); });
  ok('relative URLs made absolute; protocol-relative images fixed', () => { const o = j.offers.find(x => x.storeId === 'snp' && x.price === 5499); assert.equal(decodeURIComponent(new URL(o.url).searchParams.get('url')), 'https://www.snapdeal.com/product/air-fryer-1'); assert.equal(o.image, 'https://img.snap.test/a.jpg'); });
  ok('Cuelinks wrapping on scraped stores only', () => { assert.match(j.offers.find(x => x.storeId === 'snp').url, /linksredirect\.com\/\?cid=999/); assert.ok(!j.offers.find(x => x.storeId === 'amz').url.includes('linksredirect')); });
  ok('per-store rules mode used for IKEA (extract_rules sent, render off)', () => { const o = j.offers.find(x => x.storeId === 'ike'); assert.equal(o.title, 'Rule Based Air Fryer'); assert.equal(o.price, 3999); assert.ok(sbLog.some(c => c.extract_rules && c.render_js === 'false')); });
  ok('sorted by price ascending', () => { for (let i = 1; i < j.offers.length; i++) assert.ok(j.offers[i].price >= j.offers[i - 1].price); });
  ok('SerpApi fallback ran (fewer than MIN_OFFERS) and de-duplicated Amazon', () => { assert.equal(serpCalls, 1); assert.ok(j.offers.some(x => x.store === 'Croma')); assert.ok(!j.offers.some(x => x.title === 'Amazon dup')); });
  ok('meta.sources reports each provider', () => { assert.equal(j.meta.sources.amz.status, 'ok'); assert.equal(j.meta.sources.flk.status, 'ok'); assert.ok(j.meta.sources.snp && j.meta.sources.ike && j.meta.sources.clq); });

  const calls = sbCalls;
  const again = await get('/api/search?q=air%20fryer&category=home');
  ok('second identical search is a cache hit: no new ScrapingBee/SerpApi calls', () => { assert.equal(again.j.meta.cached, true); assert.equal(sbCalls, calls); assert.equal(serpCalls, 1); });

  console.log('YouTube');
  const y = await get('/api/youtube-reviews?q=air%20fryer');
  ok('videos in the app\'s shape (duration seconds, url, thumbnail)', () => { const v = y.j.videos[0]; assert.equal(v.videoId, 'abc123'); assert.equal(v.duration, 754); assert.equal(v.url, 'https://www.youtube.com/watch?v=abc123'); assert.match(v.thumbnail, /ytimg/); });

  console.log('Budget guard + failure isolation (cap = 40 credits/day)');
  const bud = await get('/api/search?q=sofa%20needsjs&category=furniture');
  ok('JS retry path works (plain 1 credit empty -> JS 5 credits)', () => { assert.ok(sbLog.some(c => c.url.includes('needsjs') && c.render_js === 'true')); });
  const hard = await get('/api/search?q=crm-fails&category=tv');
  ok('a failing store is reported as error but search still returns 200', () => { assert.equal(hard.r.status, 200); assert.ok(['error', 'skipped', 'empty'].includes(hard.j.meta.sources.crm?.status)); });
  const st = await (await fetch(B + '/admin/status', { headers: { 'x-admin-key': 'adm' } })).json();
  ok('admin status shows configured providers and credits used', () => { assert.equal(st.configured.flipkart, true); assert.ok(st.budgets.scrapingbee.used <= 40); });
  const noauth = await fetch(B + '/admin/status');
  ok('admin 401 without key', () => assert.equal(noauth.status, 401));

  console.log('Validation');
  assert.equal((await fetch(B + '/api/search')).status, 400); pass++; console.log('  ✓ missing q returns 400');
  const nf = await fetch(B + '/nope'); assert.equal(nf.status, 404); pass++; console.log('  ✓ unknown route returns 404');
} finally { srv.kill(); mock.close(); }
console.log(`\n${pass} checks passed${process.exitCode ? ', SOME FAILED' : ''}`);
