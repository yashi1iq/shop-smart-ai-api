import test from 'node:test';
import assert from 'node:assert/strict';
import { config } from '../src/config.js';
import { createApp, cleanQuery } from '../src/app.js';
import { parsePrice, normalizeShoppingResult } from '../src/providers/serpapi.js';
import { isoToSeconds, decodeEntities } from '../src/providers/youtube.js';
import { detectBrand } from '../src/brands.js';
import { Cache } from '../src/cache.js';

/* Upstream calls (SerpAPI, YouTube) are stubbed. Calls to our own test server go through the real fetch. */
const realFetch = globalThis.fetch;
let upstream = [];
let handler = () => {
  throw new Error('no upstream handler set');
};
globalThis.fetch = async (url, opts) => {
  const u = String(url);
  if (u.startsWith('http://127.0.0.1')) return realFetch(url, opts);
  upstream.push(u);
  return handler(u);
};
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

const baseConfig = { ...config };
async function start(overrides = {}) {
  Object.assign(config, baseConfig, { serpApiKey: 'test-key', youtubeApiKey: 'yt-key', mock: false, ...overrides });
  upstream = [];
  const app = createApp();
  const server = await new Promise(r => {
    const s = app.listen(0, '127.0.0.1', () => r(s));
  });
  return { base: `http://127.0.0.1:${server.address().port}`, close: () => new Promise(r => server.close(r)) };
}

const SHOPPING = {
  shopping_results: [
    {
      position: 1,
      title: 'Apple iPhone 16 Pro 256 GB',
      product_id: 'p1',
      source: 'Amazon.in',
      price: '₹1,19,900.00',
      extracted_price: 119900,
      old_price: '₹1,34,900.00',
      extracted_old_price: 134900,
      rating: 4.6,
      reviews: 1523,
      thumbnail: 'https://img.example/p1.jpg',
      link: 'https://www.amazon.in/dp/B0TEST',
      delivery: 'Free delivery',
      extensions: ['11% OFF', 'Free delivery', '256 GB']
    },
    {
      position: 2,
      title: 'Apple iPhone 16 Pro 256 GB',
      source: 'Flipkart',
      price: '₹1,21,900',
      product_link: 'https://www.google.com/shopping/product/123',
      rating: 4.5,
      reviews: 880
    },
    { position: 3, title: 'No price listing', source: 'Somewhere' },
    { position: 4, title: 'Apple iPhone 16 Pro 256 GB', source: 'Flipkart', price: '₹1,21,900' }
  ]
};

test('parsePrice reads common Indian price formats', () => {
  assert.equal(parsePrice('₹24,999.00'), 24999);
  assert.equal(parsePrice('Rs. 1,299'), 1299);
  assert.equal(parsePrice('From ₹499'), 499);
  assert.equal(parsePrice(1299), 1299);
  assert.equal(parsePrice('free'), null);
  assert.equal(parsePrice(0), null);
});

test('normalizeShoppingResult maps fields and drops unusable rows', () => {
  const o = normalizeShoppingResult(SHOPPING.shopping_results[0]);
  assert.equal(o.price, 119900);
  assert.equal(o.mrp, 134900);
  assert.equal(o.discount, 11);
  assert.equal(o.brand, 'Apple');
  assert.equal(o.store, 'Amazon.in');
  assert.equal(o.url, 'https://www.amazon.in/dp/B0TEST');
  assert.equal(o.inStock, null);
  assert.deepEqual(o.specs, ['256 GB']);
  assert.equal(normalizeShoppingResult(SHOPPING.shopping_results[2]), null);
  const oos = normalizeShoppingResult({ title: 'X', source: 'S', price: '₹10', extensions: ['Out of stock'] });
  assert.equal(oos.inStock, false);
  const bad = normalizeShoppingResult({ title: 'X', source: 'S', price: '₹10', old_price: '₹5', rating: 9 });
  assert.equal(bad.mrp, null);
  assert.equal(bad.rating, null);
});

test('detectBrand finds brands without false positives', () => {
  assert.equal(detectBrand('Apple iPhone 16 Pro'), 'Apple');
  assert.equal(detectBrand("Levi's 511 Slim Fit Jeans"), "Levi's");
  assert.equal(detectBrand('Wireless headphones with noise cancellation'), null);
});

test('cleanQuery trims, collapses whitespace and enforces length', () => {
  assert.equal(cleanQuery('  iphone   16\n pro '), 'iphone 16 pro');
  assert.equal(cleanQuery('a'), null);
  assert.equal(cleanQuery('x'.repeat(121)), null);
  assert.equal(cleanQuery(undefined), null);
  assert.equal(cleanQuery(['tv', 'x']), 'tv');
});

test('Cache shares in-flight calls and serves stale data when the source fails', async () => {
  const cache = new Cache({ staleMs: 60000 });
  let n = 0;
  const slow = async () => {
    n++;
    await new Promise(r => setTimeout(r, 20));
    return 'v' + n;
  };
  const [a, b] = await Promise.all([cache.remember('k', 1, slow), cache.remember('k', 1, slow)]);
  assert.equal(n, 1);
  assert.equal(a.value, 'v1');
  assert.equal(b.value, 'v1');
  await new Promise(r => setTimeout(r, 5)); /* expire the 1 ms TTL */
  const stale = await cache.remember('k', 1, async () => {
    throw new Error('down');
  });
  assert.equal(stale.stale, true);
  assert.equal(stale.value, 'v1');
  await assert.rejects(cache.remember('other', 1, async () => {
    throw new Error('down');
  }));
});

test('GET /api/search returns normalized offers and then serves from cache', async () => {
  const s = await start();
  handler = () => json(SHOPPING);
  try {
    const r1 = await fetch(`${s.base}/api/search?q=${encodeURIComponent('iPhone 16 Pro')}&category=electronics`);
    assert.equal(r1.status, 200);
    assert.equal(r1.headers.get('x-cache'), 'MISS');
    assert.equal(r1.headers.get('x-shopsmart-data'), 'live');
    assert.equal(r1.headers.get('access-control-allow-origin'), '*');
    const b1 = await r1.json();
    assert.equal(b1.category, 'electronics');
    assert.equal(b1.count, 2); /* one row has no price, one is a duplicate */
    assert.equal(b1.offers[0].store, 'Amazon.in');

    const r2 = await fetch(`${s.base}/api/search?query=${encodeURIComponent('iphone 16 pro')}`);
    assert.equal(r2.headers.get('x-cache'), 'HIT');
    assert.equal(upstream.length, 1);
    const u = new URL(upstream[0]);
    assert.equal(u.searchParams.get('engine'), 'google_shopping');
    assert.equal(u.searchParams.get('gl'), 'in');
    assert.equal(u.searchParams.get('api_key'), 'test-key');
  } finally {
    await s.close();
  }
});

test('GET /api/search validates the query', async () => {
  const s = await start();
  try {
    const r = await fetch(`${s.base}/api/search?q=a`);
    assert.equal(r.status, 400);
    assert.equal((await r.json()).error, 'invalid_query');
  } finally {
    await s.close();
  }
});

test('GET /api/search reports a missing key clearly', async () => {
  const s = await start({ serpApiKey: '' });
  try {
    const r = await fetch(`${s.base}/api/search?q=laptop`);
    assert.equal(r.status, 503);
    assert.equal((await r.json()).error, 'not_configured');
  } finally {
    await s.close();
  }
});

test('GET /api/search treats "no results" as an empty list and maps provider failures', async () => {
  let s = await start();
  handler = () => json({ error: "Google hasn't returned any results for this query." });
  try {
    const r = await fetch(`${s.base}/api/search?q=zzzzqqqq`);
    assert.equal(r.status, 200);
    assert.equal((await r.json()).count, 0);
  } finally {
    await s.close();
  }
  s = await start();
  handler = () => json({ error: 'Invalid API key.' }, 401);
  try {
    const r = await fetch(`${s.base}/api/search?q=laptop`);
    assert.equal(r.status, 502);
    assert.equal((await r.json()).error, 'provider_auth');
  } finally {
    await s.close();
  }
  s = await start();
  handler = () => json({}, 429);
  try {
    const r = await fetch(`${s.base}/api/search?q=laptop`);
    assert.equal(r.status, 503);
    assert.equal((await r.json()).error, 'provider_quota');
  } finally {
    await s.close();
  }
});

test('MOCK=1 serves clearly marked sample data only when no key is set', async () => {
  const s = await start({ serpApiKey: '', mock: true });
  try {
    const r = await fetch(`${s.base}/api/search?q=earbuds`);
    assert.equal(r.status, 200);
    assert.equal(r.headers.get('x-shopsmart-data'), 'mock');
    const b = await r.json();
    assert.ok(b.count > 0);
    assert.equal(upstream.length, 0);
  } finally {
    await s.close();
  }
});

test('GET /api/youtube-reviews filters Shorts and decodes titles', async () => {
  const s = await start();
  handler = url => {
    if (url.includes('/search?')) {
      return json({
        items: [
          { id: { videoId: 'aaa' }, snippet: { title: 'iPhone 16 Pro &amp; Max review &#39;honest&#39;', channelTitle: 'Tech &amp; Co', thumbnails: { high: { url: 'https://i.ytimg.com/a.jpg' } }, publishedAt: '2026-09-01T00:00:00Z' } },
          { id: { videoId: 'bbb' }, snippet: { title: 'Short clip', channelTitle: 'X', thumbnails: {} } }
        ]
      });
    }
    return json({
      items: [
        { id: 'aaa', contentDetails: { duration: 'PT12M30S' }, statistics: { viewCount: '12345' } },
        { id: 'bbb', contentDetails: { duration: 'PT45S' }, statistics: {} }
      ]
    });
  };
  try {
    const r = await fetch(`${s.base}/api/youtube-reviews?q=${encodeURIComponent('iphone 16 pro')}`);
    assert.equal(r.status, 200);
    const b = await r.json();
    assert.equal(b.videos.length, 1);
    assert.equal(b.videos[0].title, "iPhone 16 Pro & Max review 'honest'");
    assert.equal(b.videos[0].channelTitle, 'Tech & Co');
    assert.equal(b.videos[0].duration, 'PT12M30S');
    assert.equal(b.videos[0].url, 'https://www.youtube.com/watch?v=aaa');
    assert.equal(new URL(upstream[0]).searchParams.get('q'), 'iphone 16 pro review');

    await fetch(`${s.base}/api/youtube-reviews?q=${encodeURIComponent('iphone 16 pro')}`);
    assert.equal(upstream.length, 2, 'second request is served from cache');
  } finally {
    await s.close();
  }
});

test('YouTube helpers', () => {
  assert.equal(isoToSeconds('PT1H2M3S'), 3723);
  assert.equal(isoToSeconds('PT45S'), 45);
  assert.equal(isoToSeconds('garbage'), 0);
  assert.equal(decodeEntities('a &amp; b &#39;c&#39; &#8211;'), "a & b 'c' –");
});

test('rate limiting answers 429 with Retry-After', async () => {
  const s = await start({ rateLimitPerMin: 2 });
  handler = () => json(SHOPPING);
  try {
    assert.equal((await fetch(`${s.base}/api/search?q=laptop`)).status, 200);
    assert.equal((await fetch(`${s.base}/api/search?q=laptop`)).status, 200);
    const r = await fetch(`${s.base}/api/search?q=laptop`);
    assert.equal(r.status, 429);
    assert.ok(r.headers.get('retry-after'));
  } finally {
    await s.close();
  }
});

test('CORS: preflight, restricted origins and unsupported methods', async () => {
  const s = await start({ allowedOrigins: ['https://shop.example'] });
  try {
    const pre = await fetch(`${s.base}/api/search?q=tv`, { method: 'OPTIONS', headers: { Origin: 'https://shop.example', 'Access-Control-Request-Method': 'GET' } });
    assert.equal(pre.status, 204);
    assert.equal(pre.headers.get('access-control-allow-origin'), 'https://shop.example');
    assert.match(pre.headers.get('access-control-allow-methods'), /GET/);

    handlerForCors();
    const ok = await fetch(`${s.base}/api/search?q=tv`, { headers: { Origin: 'https://shop.example' } });
    assert.equal(ok.headers.get('access-control-allow-origin'), 'https://shop.example');
    const bad = await fetch(`${s.base}/api/search?q=tv`, { headers: { Origin: 'https://evil.example' } });
    assert.equal(bad.headers.get('access-control-allow-origin'), null);

    const post = await fetch(`${s.base}/api/search?q=tv`, { method: 'POST' });
    assert.equal(post.status, 405);
  } finally {
    await s.close();
  }
});
function handlerForCors() {
  handler = () => json(SHOPPING);
}

test('health and unknown routes', async () => {
  const s = await start();
  try {
    const h = await (await fetch(`${s.base}/api/health`)).json();
    assert.equal(h.status, 'ok');
    assert.equal(h.providers.shopping, 'serpapi');
    assert.equal(JSON.stringify(h).includes('test-key'), false, 'health must never leak keys');
    assert.equal((await fetch(`${s.base}/nope`)).status, 404);
  } finally {
    await s.close();
  }
});
