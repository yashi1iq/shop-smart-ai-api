/* Small in-memory TTL cache with request de-duplication and stale-on-error.
   - Identical concurrent requests share one upstream call.
   - If the upstream fails and an older value exists (up to staleMs), that value is served instead. */
export class Cache {
  constructor({ max = 500, staleMs = 0 } = {}) {
    this.max = max;
    this.staleMs = staleMs;
    this.map = new Map();
    this.inflight = new Map();
  }

  peek(key) {
    const e = this.map.get(key);
    if (!e) return null;
    const now = Date.now();
    if (now > e.expires + this.staleMs) {
      this.map.delete(key);
      return null;
    }
    return { value: e.value, fresh: now <= e.expires, at: e.at };
  }

  set(key, value, ttlMs) {
    this.map.delete(key);
    this.map.set(key, { value, expires: Date.now() + ttlMs, at: Date.now() });
    while (this.map.size > this.max) this.map.delete(this.map.keys().next().value);
  }

  clear() {
    this.map.clear();
    this.inflight.clear();
  }

  async remember(key, ttlMs, fn) {
    const hit = this.peek(key);
    if (hit && hit.fresh) return { value: hit.value, cached: true, stale: false, at: hit.at };

    let p = this.inflight.get(key);
    if (!p) {
      p = (async () => {
        try {
          const v = await fn();
          this.set(key, v, ttlMs);
          return v;
        } finally {
          this.inflight.delete(key);
        }
      })();
      this.inflight.set(key, p);
    }
    try {
      const value = await p;
      return { value, cached: false, stale: false, at: Date.now() };
    } catch (err) {
      if (hit) return { value: hit.value, cached: true, stale: true, at: hit.at };
      throw err;
    }
  }
}
