/* Load .env for local development. Variables already set (for example on Railway) are never overridden. */
try {
  process.loadEnvFile();
} catch (e) {
  /* no .env file: fine */
}

const int = (v, d) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : d;
};

/* Mutable on purpose: tests change values on this object. */
export const config = {
  port: int(process.env.PORT, 3000),
  serpApiKey: (process.env.SERPAPI_KEY || '').trim(),
  youtubeApiKey: (process.env.YOUTUBE_API_KEY || '').trim(),
  mock: process.env.MOCK === '1',
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean),
  searchCacheMs: int(process.env.SEARCH_CACHE_SECONDS, 900) * 1000,
  youtubeCacheMs: int(process.env.YOUTUBE_CACHE_SECONDS, 86400) * 1000,
  staleMs: 24 * 60 * 60 * 1000,
  rateLimitPerMin: int(process.env.RATE_LIMIT_PER_MINUTE, 60),
  maxResults: int(process.env.MAX_RESULTS, 40),
  /* Behind Railway's proxy the real client IP is the last X-Forwarded-For entry. Only trust it when a proxy is really in front. */
  trustProxy: process.env.TRUST_PROXY === '1' || !!process.env.RAILWAY_ENVIRONMENT,
  upstreamTimeoutMs: int(process.env.UPSTREAM_TIMEOUT_MS, 15000),
  serpApiUrl: process.env.SERPAPI_URL || 'https://serpapi.com/search.json',
  youtubeApiUrl: process.env.YOUTUBE_API_URL || 'https://www.googleapis.com/youtube/v3'
};

/* Category ids the app sends in ?category=. Unknown values are ignored, never rejected. */
export const CATEGORY_IDS = new Set([
  'electronics', 'beauty', 'fashion', 'footwear', 'home', 'furniture', 'computers', 'cameras', 'gaming', 'tv',
  'mobileacc', 'watches', 'jewellery', 'toys', 'sports', 'auto', 'pets', 'books', 'grocery', 'health', 'travel',
  'tools', 'garden', 'gifts'
]);
