/* Google Shopping does not return a brand field, so we recognise common brands from the title. */
const BRANDS = [
  'Apple', 'Samsung', 'Google', 'OnePlus', 'Sony', 'LG', 'Dell', 'HP', 'Lenovo', 'Asus', 'Acer', 'MSI', 'Canon', 'Nikon',
  'Fujifilm', 'GoPro', 'Maybelline', 'Lakme', 'Nivea', 'Cetaphil', 'Neutrogena', 'Minimalist', 'Garnier', 'Olay',
  'Clinique', 'Mamaearth', 'Revlon', "L'Oreal", 'Loreal', 'Dyson', 'Philips', 'Xiaomi', 'Redmi', 'Realme', 'Poco',
  'Vivo', 'Oppo', 'Motorola', 'Nokia', 'boAt', 'JBL', 'Bose', 'Sennheiser', 'Fire-Boltt',
  "Levi's", 'Nike', 'Adidas', 'Puma', 'Reebok', 'Crocs', 'Skechers', 'Bata', 'Woodland', 'Fastrack', 'Titan',
  'Casio', 'Fossil', 'Timex', 'LEGO', 'Funko', 'Whirlpool', 'Bosch', 'IFB', 'Haier', 'Voltas', 'Daikin', 'Panasonic',
  'Prestige', 'Pigeon', 'Bajaj', 'Havells', 'Usha', 'Butterfly', 'Milton', 'Cello', 'Tefal', 'Microsoft', 'Nintendo',
  'Logitech', 'Razer', 'Corsair', 'SanDisk', 'Kingston', 'Seagate', 'Western Digital', 'TP-Link', 'Anker', 'Ambrane',
  'Zebronics', 'Allen Solly', 'Peter England', 'Van Heusen', 'Raymond', 'Fabindia', 'Biba', 'W', 'Pepperfry', 'IKEA',
  'Wakefit', 'Sleepwell', 'Godrej', 'Durian', 'Himalaya', 'Dabur', 'Patanjali', 'Tata', 'Amul', 'Nestle', 'Britannia'
];

const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/* Multi-letter brands only: single letters like "W" would match too much. */
const MATCHERS = BRANDS.filter(b => b.length > 1).map(b => ({
  name: b,
  re: new RegExp(`(^|[^a-z0-9])${esc(b.toLowerCase())}(?![a-z0-9])`, 'i')
}));

export function detectBrand(title) {
  const t = String(title || '');
  let best = null;
  let bestIdx = Infinity;
  for (const m of MATCHERS) {
    const found = m.re.exec(t);
    if (found && found.index < bestIdx) {
      best = m.name;
      bestIdx = found.index;
    }
  }
  return best;
}
