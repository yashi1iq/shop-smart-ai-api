import { config } from './config.js';
import { createApp } from './app.js';

const server = createApp();

server.listen(config.port, '0.0.0.0', () => {
  const shopping = config.serpApiKey ? 'SerpAPI' : config.mock ? 'MOCK DATA (development only)' : 'NOT CONFIGURED (set SERPAPI_KEY)';
  console.log(`ShopSmart AI API listening on port ${config.port}`);
  console.log(`  Shopping provider: ${shopping}`);
  console.log(`  YouTube provider:  ${config.youtubeApiKey ? 'YouTube Data API' : 'NOT CONFIGURED (set YOUTUBE_API_KEY)'}`);
  if (config.mock && !config.serpApiKey) {
    console.warn('  WARNING: MOCK=1 serves generated sample prices. Do not use it in production.');
  }
});

/* Railway sends SIGTERM on every deploy: finish in-flight requests, then exit. */
const shutdown = signal => {
  console.log(`${signal} received, shutting down`);
  server.close(() => process.exit(0));
  server.closeIdleConnections?.();
  setTimeout(() => process.exit(1), 10000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
