import http from 'node:http';
import { config, CATEGORY_IDS } from './config.js';
import { Cache } from './cache.js';
import { createLimiter } from './limiter.js';
import { ApiError } from './errors.js';
import { searchShopping } from './providers/serpapi.js';
import { mockShopping } from './providers/mock.js';
import { youtubeReviews } from './providers/youtube.js';

/* Trims, collapses whitespace and strips control characters. Returns null if the query is unusable. */
export function cleanQuery(v) {
  if (Array.isArray(v)) v = v[0];
  if (typeof v !== 'string') return null;
  const q = v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  return q.length >= 2 && q.length <= 120 ? q : null;
}

const badQuery = () => new ApiError(400, 'invalid_query', 'Send a search term of 2 to 120 characters in the q parameter');

function send(res, status, body, headers = {}) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(data),
    'X-Content-Type-Options': 'nosniff',
    ...headers
  });
  res.end(res.req && res.req.method === 'HEAD' ? undefined : data);
}

/* Sets CORS headers. Browsers from other sites can only read responses when their origin is allowed. */
function applyCors(req, res) {
  const origin = req.headers.origin;
  if (config.allowedOrigins.includes('*')) {
    res.setHeader('Access-Control-Allow-Origin', '*');
  } else if (origin && config.allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
}

/* Returns an http.Server that is not yet listening (call .listen on it). */
export function createApp() {
  const searchCache = new Cache({ max: 500, staleMs: config.staleMs });
  const videoCache = new Cache({ max: 500, staleMs: config.staleMs });
  const limiter = createLimiter({ windowMs: 60000, max: config.rateLimitPerMin });
  const startedAt = Date.now();

  /* GET /api/search?q=iphone 16&category=electronics
     Returns { query, category, count, offers: [...] } where each offer is one store listing. */
  async function handleSearch(req, res, url) {
    const q = cleanQuery(url.searchParams.get('q') ?? url.searchParams.get('query'));
    if (!q) throw badQuery();
    const c = String(url.searchParams.get('category') || '').toLowerCase();
    const category = CATEGORY_IDS.has(c) ? c : null;

    const useMock = config.mock && !config.serpApiKey;
    const key = `${useMock ? 'mock' : 'live'}|${q.toLowerCase()}`;
    const r = await searchCache.remember(key, config.searchCacheMs, async () => (useMock ? mockShopping(q) : searchShopping(q)));

    send(
      res,
      200,
      {
        query: q,
        category,
        count: r.value.length,
        cached: r.cached,
        stale: r.stale,
        updatedAt: new Date(r.at).toISOString(),
        offers: r.value
      },
      {
        'Cache-Control': 'no-store',
        'X-Cache': r.stale ? 'STALE' : r.cached ? 'HIT' : 'MISS',
        'X-ShopSmart-Data': useMock ? 'mock' : 'live'
      }
    );
  }

  /* GET /api/youtube-reviews?q=iphone 16
     Returns { query, videos: [{ videoId, title, channelTitle, thumbnail, duration, url }] }. */
  async function handleVideos(req, res, url) {
    const q = cleanQuery(url.searchParams.get('q') ?? url.searchParams.get('query'));
    if (!q) throw badQuery();
    if (config.mock && !config.youtubeApiKey) {
      return send(res, 200, { query: q, videos: [] }, { 'X-ShopSmart-Data': 'mock' });
    }
    const r = await videoCache.remember(q.toLowerCase(), config.youtubeCacheMs, () => youtubeReviews(q));
    send(res, 200, { query: q, videos: r.value }, {
      'Cache-Control': 'public, max-age=3600',
      'X-Cache': r.stale ? 'STALE' : r.cached ? 'HIT' : 'MISS'
    });
  }

  function handleHealth(req, res) {
    const shopping = config.serpApiKey ? 'serpapi' : config.mock ? 'mock' : 'unconfigured';
    send(
      res,
      200,
      {
        status: 'ok',
        uptimeSeconds: Math.round((Date.now() - startedAt) / 1000),
        providers: { shopping, youtube: config.youtubeApiKey ? 'youtube-data-api' : 'unconfigured' },
        cache: { searches: searchCache.map.size, videos: videoCache.map.size }
      },
      { 'Cache-Control': 'no-store' }
    );
  }

  const server = http.createServer(async (req, res) => {
    try {
      applyCors(req, res);

      if (req.method === 'OPTIONS') {
        res.writeHead(204, {
          'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
          'Access-Control-Allow-Headers': req.headers['access-control-request-headers'] || 'Accept, Content-Type',
          'Access-Control-Max-Age': '600',
          'Content-Length': '0'
        });
        return res.end();
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        return send(res, 405, { error: 'method_not_allowed', message: 'Only GET requests are supported' }, { Allow: 'GET, HEAD, OPTIONS' });
      }

      const url = new URL(req.url, 'http://localhost');
      const path = url.pathname.length > 1 ? url.pathname.replace(/\/+$/, '') : url.pathname;

      if (path === '/') {
        return send(res, 200, {
          name: 'ShopSmart AI API',
          status: 'ok',
          endpoints: ['/api/search?q=<product>&category=<id>', '/api/youtube-reviews?q=<product>', '/api/health']
        });
      }
      if (path === '/api/health') return handleHealth(req, res);

      if (path === '/api/search' || path === '/search') {
        if (!limiter(req, res, send)) return;
        return await handleSearch(req, res, url);
      }
      if (path === '/api/youtube-reviews') {
        if (!limiter(req, res, send)) return;
        return await handleVideos(req, res, url);
      }

      send(res, 404, { error: 'not_found', message: `No route for ${req.method} ${path}` });
    } catch (err) {
      if (res.headersSent) return res.end();
      if (err instanceof ApiError) return send(res, err.status, { error: err.code, message: err.message });
      console.error('Unhandled error:', err);
      send(res, 500, { error: 'internal_error', message: 'Something went wrong on the server' });
    }
  });

  server.keepAliveTimeout = 65000; /* longer than Railway's proxy idle timeout */
  server.locals = { caches: { searchCache, videoCache } };
  return server;
}
