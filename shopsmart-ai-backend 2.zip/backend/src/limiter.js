import { config } from './config.js';

/* Client IP: the last X-Forwarded-For entry when a trusted proxy (Railway) is in front, otherwise the socket address. */
export function clientIp(req) {
  if (config.trustProxy) {
    const xff = String(req.headers['x-forwarded-for'] || '');
    const last = xff.split(',').pop().trim();
    if (last) return last;
  }
  return req.socket.remoteAddress || 'unknown';
}

/* Fixed-window rate limiter. check(req, res) returns true when allowed; otherwise it has already sent the 429. */
export function createLimiter({ windowMs = 60000, max = 60 } = {}) {
  const hits = new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset <= now) hits.delete(k);
  }, windowMs).unref();

  return function check(req, res, send) {
    const ip = clientIp(req);
    const now = Date.now();
    let h = hits.get(ip);
    if (!h || h.reset <= now) {
      h = { n: 0, reset: now + windowMs };
      hits.set(ip, h);
    }
    h.n++;
    res.setHeader('RateLimit-Limit', String(max));
    res.setHeader('RateLimit-Remaining', String(Math.max(0, max - h.n)));
    if (h.n > max) {
      res.setHeader('Retry-After', String(Math.ceil((h.reset - now) / 1000)));
      send(res, 429, { error: 'rate_limited', message: 'Too many requests. Try again shortly.' });
      return false;
    }
    return true;
  };
}
