/* An error that already knows which HTTP status and public message to send. */
export class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/* fetch() with a timeout that turns network problems into ApiErrors. */
export async function fetchJson(url, { timeoutMs = 15000, label = 'upstream' } = {}) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(url, { signal: ctl.signal, headers: { Accept: 'application/json' } });
  } catch (e) {
    throw new ApiError(504, 'upstream_unreachable', e.name === 'AbortError' ? `${label} timed out` : `${label} could not be reached`);
  } finally {
    clearTimeout(t);
  }
  let body = null;
  try {
    body = await res.json();
  } catch (e) {
    /* body stays null */
  }
  return { status: res.status, ok: res.ok, body };
}
