import { config } from '../config.js';
import { ApiError, fetchJson } from '../errors.js';
import { detectBrand } from '../brands.js';

/* Turns "₹24,999.00" or "Rs. 1,299" into a number, or null. */
export function parsePrice(v) {
  if (v == null) return null;
  if (typeof v === 'number') return Number.isFinite(v) && v > 0 ? v : null;
  const m = String(v).match(/\d[\d,]*(?:\.\d+)?/);
  if (!m) return null;
  const n = parseFloat(m[0].replace(/,/g, ''));
  return Number.isFinite(n) && n > 0 ? n : null;
}

const num = v => (typeof v === 'number' && Number.isFinite(v) ? v : parsePrice(v));

/* Converts one SerpAPI google_shopping result into the offer shape the app reads. Returns null if it has no usable price. */
export function normalizeShoppingResult(r, i = 0) {
  if (!r || typeof r !== 'object') return null;
  const price = num(r.extracted_price) ?? parsePrice(r.price);
  const title = String(r.title || '').trim();
  const store = String(r.source || '').trim();
  if (!price || !title || !store) return null;

  let mrp = num(r.extracted_old_price) ?? parsePrice(r.old_price);
  if (mrp != null && mrp <= price) mrp = null;
  let discount = mrp ? Math.round(((mrp - price) / mrp) * 100) : null;
  if (!discount && r.tag) {
    const m = String(r.tag).match(/(\d{1,2})\s*%\s*off/i);
    if (m) discount = parseInt(m[1], 10);
  }

  const ext = Array.isArray(r.extensions) ? r.extensions.map(String) : [];
  const outOfStock = ext.some(x => /out of stock|sold out|unavailable/i.test(x));
  const specs = ext.filter(x => x.length <= 40 && !/off\b|delivery|shipping|out of stock|sold out|unavailable/i.test(x)).slice(0, 4);

  const rating = num(r.rating);
  const reviews = num(r.reviews);

  return {
    id: String(r.product_id || r.position || i),
    title,
    brand: detectBrand(title),
    price,
    mrp,
    discount: discount && discount > 0 ? discount : null,
    currency: 'INR',
    rating: rating != null && rating >= 0 && rating <= 5 ? Math.round(rating * 10) / 10 : null,
    reviews: reviews != null ? Math.round(reviews) : null,
    /* Google Shopping lists available offers. Only mark out of stock when the listing says so; otherwise stock is unknown. */
    inStock: outOfStock ? false : null,
    availText: outOfStock ? 'Out of stock' : null,
    store,
    delivery: r.delivery ? String(r.delivery) : null,
    image: r.thumbnail || null,
    url: r.link || r.product_link || null,
    specs
  };
}

export function normalizeShoppingResults(results, max = config.maxResults) {
  const seen = new Set();
  const out = [];
  (Array.isArray(results) ? results : []).forEach((r, i) => {
    const o = normalizeShoppingResult(r, i);
    if (!o) return;
    const k = `${o.store}|${o.title}|${o.price}`.toLowerCase();
    if (seen.has(k)) return;
    seen.add(k);
    out.push(o);
  });
  return out.slice(0, max);
}

export async function searchShopping(q) {
  if (!config.serpApiKey) {
    throw new ApiError(503, 'not_configured', 'The price service has no SERPAPI_KEY configured');
  }
  const params = new URLSearchParams({
    engine: 'google_shopping',
    q,
    gl: 'in',
    hl: 'en',
    google_domain: 'google.co.in',
    api_key: config.serpApiKey
  });
  const { status, ok, body } = await fetchJson(`${config.serpApiUrl}?${params}`, {
    timeoutMs: config.upstreamTimeoutMs,
    label: 'Price provider'
  });

  const upstreamMsg = body && body.error ? String(body.error) : '';
  /* SerpAPI answers a no-results search with an error string rather than an empty list. */
  if (/hasn'?t returned any results|no results/i.test(upstreamMsg)) return [];

  if (status === 401 || status === 403) throw new ApiError(502, 'provider_auth', 'The price provider rejected the API key');
  if (status === 429) throw new ApiError(503, 'provider_quota', 'The price provider quota is used up. Try again later');
  if (!ok || upstreamMsg) {
    throw new ApiError(502, 'provider_error', upstreamMsg ? `Price provider error: ${upstreamMsg}` : `Price provider answered with status ${status}`);
  }
  return normalizeShoppingResults(body && body.shopping_results);
}
