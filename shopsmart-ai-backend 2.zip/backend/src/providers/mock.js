/* Development-only generator, used when MOCK=1 and no SERPAPI_KEY is set.
   It produces deterministic fake offers so the app can be exercised without an API key.
   Responses from this provider are marked with the X-ShopSmart-Data: mock header. */
const STORES = [
  ['Amazon.in', 'https://www.amazon.in/s?k='],
  ['Flipkart', 'https://www.flipkart.com/search?q='],
  ['Croma', 'https://www.croma.com/searchB?q='],
  ['Reliance Digital', 'https://www.reliancedigital.in/search?q='],
  ['Tata CLiQ', 'https://www.tatacliq.com/search/?text=']
];

const hash = s => {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};
const rng = seed => () => {
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

export function mockShopping(q) {
  const r = rng(hash(q.toLowerCase()));
  const base = Math.round((800 + r() * 60000) / 10) * 10;
  const variants = ['', ' (Pro)', ' (Lite)'];
  const offers = [];
  STORES.forEach(([store, url], si) => {
    variants.forEach((v, vi) => {
      if (r() < 0.25) return;
      const price = Math.round((base * (0.92 + r() * 0.2) * (1 + vi * 0.25)) / 10) * 10;
      const mrp = Math.round((price * (1.08 + r() * 0.25)) / 10) * 10;
      offers.push({
        id: `mock-${si}-${vi}`,
        title: `${q}${v}`,
        brand: null,
        price,
        mrp,
        discount: Math.round(((mrp - price) / mrp) * 100),
        currency: 'INR',
        rating: Math.round((3.8 + r() * 1.1) * 10) / 10,
        reviews: Math.round(80 + r() * r() * 30000),
        inStock: null,
        availText: null,
        store,
        delivery: null,
        image: null,
        url: url + encodeURIComponent(q),
        specs: []
      });
    });
  });
  return offers;
}
