import { config } from '../config.js';
import { ApiError, fetchJson } from '../errors.js';

const ENTITIES = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'", '&apos;': "'" };
/* YouTube returns titles with HTML entities. The app escapes text itself, so decode here. */
export const decodeEntities = s =>
  String(s || '')
    .replace(/&(?:amp|lt|gt|quot|apos|#39);/g, m => ENTITIES[m])
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)));

/* "PT1H2M3S" -> seconds. */
export function isoToSeconds(iso) {
  const m = String(iso || '').match(/^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
  if (!m) return 0;
  return (+m[1] || 0) * 86400 + (+m[2] || 0) * 3600 + (+m[3] || 0) * 60 + (+m[4] || 0);
}

const MIN_SECONDS = 90; /* skips Shorts and teasers */

export async function youtubeReviews(q) {
  if (!config.youtubeApiKey) {
    throw new ApiError(503, 'not_configured', 'The video service has no YOUTUBE_API_KEY configured');
  }
  const base = config.youtubeApiUrl;
  const call = async (path, params, label) => {
    const { status, ok, body } = await fetchJson(`${base}/${path}?${new URLSearchParams({ ...params, key: config.youtubeApiKey })}`, {
      timeoutMs: config.upstreamTimeoutMs,
      label
    });
    if (ok) return body || {};
    const reason = body && body.error && body.error.errors && body.error.errors[0] && body.error.errors[0].reason;
    if (reason === 'quotaExceeded' || reason === 'rateLimitExceeded') throw new ApiError(503, 'youtube_quota', 'The YouTube quota is used up for today');
    if (status === 400 || status === 403) throw new ApiError(502, 'youtube_auth', 'YouTube rejected the API key');
    throw new ApiError(502, 'youtube_error', `YouTube answered with status ${status}`);
  };

  const found = await call(
    'search',
    {
      part: 'snippet',
      type: 'video',
      maxResults: '12',
      q: `${q} review`,
      regionCode: 'IN',
      relevanceLanguage: 'en',
      safeSearch: 'moderate'
    },
    'YouTube search'
  );
  const ids = (found.items || []).map(it => it && it.id && it.id.videoId).filter(Boolean);
  if (!ids.length) return [];

  const details = await call('videos', { part: 'contentDetails,statistics', id: ids.join(',') }, 'YouTube details');
  const byId = new Map((details.items || []).map(v => [v.id, v]));

  const videos = [];
  for (const it of found.items) {
    const id = it.id && it.id.videoId;
    const d = id && byId.get(id);
    if (!d) continue;
    const dur = d.contentDetails && d.contentDetails.duration;
    if (isoToSeconds(dur) < MIN_SECONDS) continue;
    const sn = it.snippet || {};
    const th = sn.thumbnails || {};
    videos.push({
      videoId: id,
      title: decodeEntities(sn.title),
      channelTitle: decodeEntities(sn.channelTitle),
      thumbnail: (th.high || th.medium || th.default || {}).url || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
      duration: dur,
      views: d.statistics && d.statistics.viewCount ? Number(d.statistics.viewCount) : null,
      publishedAt: sn.publishedAt || null,
      url: `https://www.youtube.com/watch?v=${id}`
    });
    if (videos.length === 6) break;
  }
  return videos;
}
